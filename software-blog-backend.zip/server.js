const express = require('express');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const cors = require('cors');

// 初始化Express应用
const app = express();
const PORT = process.env.PORT || 3000;

// 确保uploads目录存在
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(uploadDir));
app.use(express.static(path.join(__dirname, 'public')));

// 配置文件上传
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        if (file.fieldname === 'screenshots') {
            const screenshotDir = path.join(uploadDir, 'screenshots');
            if (!fs.existsSync(screenshotDir)) {
                fs.mkdirSync(screenshotDir);
            }
            cb(null, screenshotDir);
        } else {
            const softwareDir = path.join(uploadDir, 'software');
            if (!fs.existsSync(softwareDir)) {
                fs.mkdirSync(softwareDir);
            }
            cb(null, softwareDir);
        }
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
        const ext = path.extname(file.originalname);
        cb(null, file.fieldname + '-' + uniqueSuffix + ext);
    }
});

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 200 * 1024 * 1024 // 200MB
    },
    fileFilter: function (req, file, cb) {
        // 简单的文件类型验证
        if (file.fieldname === 'software-package') {
            const allowedTypes = ['.exe', '.dmg', '.zip', '.tar', '.gz', '.pkg', '.msi'];
            const ext = path.extname(file.originalname).toLowerCase();
            if (allowedTypes.includes(ext)) {
                return cb(null, true);
            }
            return cb(new Error('不支持的软件包格式'));
        }
        cb(null, true);
    }
});

// 初始化SQLite数据库
const db = new sqlite3.Database('software_blog.db', (err) => {
    if (err) {
        console.error(err.message);
    }
    console.log('Connected to the software blog database.');
    
    // 创建软件表
    db.run(`CREATE TABLE IF NOT EXISTS software (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT,
        description TEXT,
        version TEXT,
        platforms TEXT,
        file_path TEXT NOT NULL,
        screenshot_paths TEXT,
        download_count INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`, (err) => {
        if (err) {
            console.error('Error creating table:', err.message);
        }
    });
});

// API路由
// 获取所有软件
app.get('/api/software', (req, res) => {
    db.all('SELECT * FROM software ORDER BY created_at DESC', (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// 获取单个软件
app.get('/api/software/:id', (req, res) => {
    const id = req.params.id;
    db.get('SELECT * FROM software WHERE id = ?', [id], (err, row) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        if (!row) {
            res.status(404).json({ error: '软件未找到' });
            return;
        }
        res.json(row);
    });
});

// 上传软件
app.post('/api/upload', upload.fields([
    { name: 'software-package', maxCount: 1 },
    { name: 'screenshots', maxCount: 5 }
]), (req, res) => {
    try {
        if (!req.files || !req.files['software-package']) {
            return res.status(400).json({ error: '请上传软件安装包' });
        }
        
        const softwareFile = req.files['software-package'][0];
        const screenshots = req.files['screenshots'] || [];
        
        // 收集截图路径
        const screenshotPaths = screenshots.map(file => 
            '/uploads/screenshots/' + file.filename
        ).join(',');
        
        // 收集软件信息
        const software = {
            name: req.body.name,
            category: req.body.category,
            description: req.body.description,
            version: req.body.version,
            platforms: req.body.platforms,
            file_path: '/uploads/software/' + softwareFile.filename,
            screenshot_paths: screenshotPaths
        };
        
        // 插入数据库
        const sql = `INSERT INTO software 
                    (name, category, description, version, platforms, file_path, screenshot_paths) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)`;
        
        db.run(sql, 
            [software.name, software.category, software.description, 
             software.version, software.platforms, software.file_path, 
             software.screenshot_paths],
            function(err) {
                if (err) {
                    return res.status(500).json({ error: err.message });
                }
                res.json({
                    success: true,
                    message: '软件上传成功',
                    id: this.lastID,
                    software: software
                });
            }
        );
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 下载软件
app.get('/api/download/:id', (req, res) => {
    const id = req.params.id;
    
    db.get('SELECT * FROM software WHERE id = ?', [id], (err, row) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (!row) {
            return res.status(404).json({ error: '软件未找到' });
        }
        
        // 构建文件路径
        const filePath = path.join(__dirname, row.file_path);
        
        // 检查文件是否存在
        fs.exists(filePath, (exists) => {
            if (!exists) {
                return res.status(404).json({ error: '文件不存在' });
            }
            
            // 增加下载计数
            db.run('UPDATE software SET download_count = download_count + 1 WHERE id = ?', [id]);
            
            // 发送文件
            res.download(filePath, (err) => {
                if (err) {
                    res.status(500).json({ error: '下载失败: ' + err.message });
                }
            });
        });
    });
});

// 前端页面路由
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 启动服务器
app.listen(PORT, () => {
    console.log(`服务器运行在 http://localhost:${PORT}`);
});

// 关闭数据库连接
process.on('SIGINT', () => {
    db.close((err) => {
        if (err) {
            console.error(err.message);
        }
        console.log('关闭数据库连接');
        process.exit(0);
    });
});
    